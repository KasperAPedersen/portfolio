<?php
  function connect(){
    $servername = "swoopai.dk.mysql";
    $username = "swoopai_dkswpdk";
    $password = "jlp7uphAKldunodruw";
    $dbname = "swoopai_dkswpdk";
    $conn = new mysqli($servername, $username, $password, $dbname); // Create connection
    if ($conn->connect_error) die("Connection failed: " . $conn->connect_error); // Throw error if connection failed
    return $conn;
  }

  function close($conn) {
    $conn->close();
  }
?>